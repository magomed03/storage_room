#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include<bits/stdc++.h>
using namespace std;
struct info
{

    string infoName;

    float infoAge;

    int personid;

};

struct Node
{

    info data;

    Node *next;

};

class List
{
private:
    Node *head;

    Node *tail;

    Node *temp;

    int nodenumber;

    int id;

public:
    List();

    void addAtFirst(info p);

    bool isEmpty();

    void removenode(info p);

    void display();

    void displaystar();
};


#endif 