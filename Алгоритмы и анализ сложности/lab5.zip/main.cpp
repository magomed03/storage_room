#include <bits/stdc++.h>
#include "header.h"
using namespace std;


int main()
{
    List l;
    info info1,info2;
    int option;
    cout << " Добро пожаловать!" << endl;
    do
    {

        cout << "Введите 1, чтобы добавить элемент" << endl;
        cout << "Введите 2, чтобы использовать display" << endl;
            cout << "Введите 3 для проверки пустоты списка" << endl;
        cout << "Введите 4, чтобы использовать displaystar.\n" << endl;
        cin>>option;
        switch(option)
        {
            case 1:
                cout<<"Введите название: " << endl;
                cin>>info1.infoName;
                cout<<"Введите возраст: " << endl;
                cin>>info1.infoAge;
                l.addAtFirst(info1);
                break;

            case 2:
                l.display();
                break;

            case 3:
                l.isEmpty();
                break;

            case 4:
                l.displaystar();
                break;
            default:
                cout<<"Вы выбрали неверную команду, повторите." << endl;

        }
    }
    while(option!=0);

    return 0;
}
