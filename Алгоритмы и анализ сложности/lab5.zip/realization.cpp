#include"header.h"
using namespace std;

// Конструтор 
List::List()
{
    head = NULL;
    tail = NULL;
    nodenumber=0;
    id=0;
}

// Эта функция добавляет элемент в начало
void List::addAtFirst(info p)
{
    temp = new Node;
    id++;
    p.personid = id;
    temp->data = p;

    if (isEmpty())
    {
        tail = temp;
        temp->next=temp;
    }
    else
    {
        temp->next = head;
        tail->next=temp;
    }

    head = temp;
    nodenumber++;
}

bool List::isEmpty()
{
    return head == NULL;
}


// Эта функция предназначена для вывода
void List::display()
{

    if (!isEmpty())
    {
        cout << "The Game has: " << nodenumber << endl;
        for (temp = head; temp->next != head; temp = temp->next)
        {
            cout << "\n ID: " << temp->data.personid << endl;
            cout << "Имя " << temp->data.infoName << ", а возраст " << temp->data.infoAge << endl;

        }
        cout << "\n ID: "<<temp->data.personid<< endl;
        cout << "Имя: " << temp->data.infoName << ", возраст: " << temp->data.infoAge<<endl;
        cout << endl;

    }
    else
    {
        cout << "Ошибка, список пуст" << endl;
    }
}
