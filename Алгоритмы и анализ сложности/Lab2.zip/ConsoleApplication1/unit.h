#ifndef HUMAN
#define HUMAN
#include "field.h"
using namespace std;

struct Coords {
    int x, y;
    Coords(int x1, int y1) {
        this->x = x1;
        this->y = y1;
    }
};

class Unit {
protected:
    int x = 0, y = 0;
    int score = 0;
    Field* field;

    Coords get_coords() {
        return Coords(x, y);
    }

public:
    int hp = 3;
    Unit(Field* field, int x, int y) {
        this->x = x;
        this->y = y;
        this->field = field;
    }

    int get_x() {
        return x;
    }

    int get_y() {
        return y;
    }

    int get_score() {
        return score;
    }

    int get_hp() {
        return hp;
    }

    virtual int new_x(char key) = 0;

    virtual int new_y(char key) = 0;

    virtual Coords NextStep(Coords dist) = 0;

    virtual void move(int x, int y, Unit* U) = 0;

    bool alive() {
        if (hp == 0) {
            return false;
        }
        return true;
    }
};

class Walker :public Unit {
public:
    Walker(Field* field, int x, int y) :Unit(field, x, y) {    }
    int new_x(char key) override {
        int dx = 0;
        switch (key) {
        case 'w':
            dx = -1;
            break;
        case 's':
            dx = 1;
            break;
        }
        return dx + x;
    }

    int new_y(char key) override {
        int dy = 0;
        switch (key) {
        case 'a':
            dy = -1;
            break;
        case 'd':
            dy = 1;
            break;
        }
        return dy + y;
    }

    Coords NextStep(Coords dist) override {
        int** A = new int* [field->w];
        for (int i = 0; i < field->w; i++) {
            A[i] = new int[field->h];
            for (int j = 0; j < field->h; j++) {
                A[i][j] = -2;
            }
        }
        A[x][y] = 0;
        bool fl = true;
        while (fl) {
            fl = false;
            for (int i = 0; i < field->w; i++) {
                for (int j = 0; j < field->h; j++) {
                    if (field->matrix_weigt(i, j) == -1)
                        continue;
                    if (i > 0) {
                        if ((A[i - 1][j] >= 0) and
                            ((A[i - 1][j] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i - 1][j] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                    if (i < field->h - 1) {
                        if ((A[i + 1][j] >= 0) and
                            ((A[i + 1][j] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i + 1][j] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                    if (j > 0) {
                        if ((A[i][j - 1] >= 0) and
                            ((A[i][j - 1] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i][j - 1] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                    if (j < field->w - 1) {
                        if ((A[i][j + 1] >= 0) and
                            ((A[i][j + 1] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i][j + 1] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                }
            }
        }

        if (A[dist.x][dist.y] < 0)
            return Coords(-1, -1);
        while (!((dist.x == x and (dist.y == y + 1 or dist.y == y - 1)) or
            (dist.y == y and (dist.x == x + 1 or dist.x == x - 1)))) {
            int up = -1, down = -1, left = -1, right = -1;
            if (dist.y > 0)
                up = A[dist.x][dist.y - 1];
            if (dist.y < field->h - 1)
                down = A[dist.x][dist.y + 1];
            if (dist.x > 0)
                left = A[dist.x - 1][dist.y];
            if (dist.x < field->w - 1)
                right = A[dist.x + 1][dist.y];
            if (up < 0)
                up = 1000000;
            if (down < 0)
                down = 1000000;
            if (left < 0)
                left = 1000000;
            if (right < 0)
                right = 1000000;
            if ((up <= down) and (up <= left) and (up <= right))
                dist.y = dist.y - 1;
            else if ((down <= up) and (down <= left) and (down <= right))
                dist.y = dist.y + 1;
            else if ((left <= down) and (left <= up) and (left <= right))
                dist.x = dist.x - 1;
            else if ((right <= down) and (right <= left) and (right <= up))
                dist.x = dist.x + 1;
        }
        return dist;

    }

    // ��������
    void move(int goal_x, int goal_y, Unit* enemy) override {
        Coords neww = NextStep(Coords(goal_x, goal_y));
        if (neww.y == -1) {
            return;
        }
        int newx = neww.x;
        int newy = neww.y;
        if (field->check(newx, newy)) {
            if (field->matrix_weigt(newx, newy) != 400000) {
                field->matrix[x][y] = '_';
                x = newx;
                y = newy;
                if (field->take_money(x, y)) {
                    score++;
                    cout << "Walker �������� ����!" << endl;
                }
                else if (field->damage(x, y)) {
                    hp--;
                    cout << "Walker ����� � �������!" << endl;
                }
                field->matrix[x][y] = '@';
            }
            else {
                enemy->hp--;
            }
        }
    }
};

class Bishop :public Unit {
public:
    Bishop(Field* field, int x, int y) : Unit(field, x, y) {}
    int new_x(char key) override {
        int dx = 0;
        switch (key) {
        case 'w':
            dx = -1;
            break;
        case 's':
            dx = 1;
            break;
        case 'e':
            dx = -1;
            break;
        case 'd':
            dx = 1;
            break;
        }
        return dx + x;
    }

    int new_y(char key) override {
        int dy = 0;
        switch (key) {
        case 'w':
            dy = -1;
            break;
        case 's':
            dy = -1;
            break;
        case 'e':
            dy = 1;
            break;
        case 'd':
            dy = 1;
            break;
        }
        return dy + y;
    }

    void move(int goal_x, int goal_y, Unit* enemy) override {
        Coords neww = NextStep(Coords(goal_x, goal_y));
        if (neww.y == -1) {
            return;
        }
        int newx = neww.x;
        int newy = neww.y;
        if (field->check(newx, newy)) {
            if (field->matrix_weigt(newx, newy) != 400000) {
                field->matrix[x][y] = '_';
                x = newx;
                y = newy;
                if (field->take_money(x, y)) {
                    score++;
                    cout << "Bishop �������� ����!" << endl;
                }
                else if (field->damage(x, y)) {
                    hp--;
                    cout << "Bishop ����� � �������!" << endl;
                }
                field->matrix[x][y] = '&';
            }
            else {
                enemy->hp--;
            }
        }
    }

    Coords NextStep(Coords dist) override {
        int** A = new int* [field->w];
        for (int i = 0; i < field->w; i++) {
            A[i] = new int[field->h];
            for (int j = 0; j < field->h; j++) {
                A[i][j] = -2;
            }
        }
        A[x][y] = 0;
        bool fl = true;
        while (fl) {
            fl = false;
            for (int i = 0; i < field->w; i++) {
                for (int j = 0; j < field->h; j++) {
                    if (field->matrix_weigt(i, j) == -1)
                        continue;
                    if (i > 0 and j > 0) {
                        if ((A[i - 1][j - 1] >= 0) and
                            ((A[i - 1][j - 1] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i - 1][j - 1] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                    if (i < field->h - 1 and j > 0) {
                        if ((A[i + 1][j - 1] >= 0) and
                            ((A[i + 1][j - 1] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i + 1][j - 1] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                    if (j < field->w - 1 and i > 0) {
                        if ((A[i - 1][j + 1] >= 0) and
                            ((A[i - 1][j + 1] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i - 1][j + 1] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                    if (j < field->w - 1 and i < field->h - 1) {
                        if ((A[i + 1][j + 1] >= 0) and
                            ((A[i + 1][j + 1] + field->matrix_weigt(i, j) < A[i][j]) or (A[i][j] == -2))) {
                            A[i][j] = A[i + 1][j + 1] + field->matrix_weigt(i, j);
                            fl = true;
                        }
                    }
                }
            }
        }
        if (A[dist.x][dist.y] < 0)
            return Coords(-1, -1);
        while (!((dist.x == x + 1 or dist.x == x - 1) and (dist.y == y + 1 or dist.y == y - 1))) {
            int up_left = -1, down_left = -1, up_right = -1, down_right = -1;
            if (dist.y > 0 and dist.x > 0)
                up_left = A[dist.x - 1][dist.y - 1];
            if (dist.y > 0 and dist.x < field->w - 1)
                down_left = A[dist.x + 1][dist.y - 1];
            if (dist.y < field->h - 1 and dist.x > 0)
                up_right = A[dist.x - 1][dist.y + 1];
            if (dist.y < field->h - 1 and dist.x < field->w - 1)
                down_right = A[dist.x + 1][dist.y + 1];
            if (up_left < 0)
                up_left = 1000000;
            if (down_left < 0)
                down_left = 1000000;
            if (up_right < 0)
                up_right = 1000000;
            if (down_right < 0)
                down_right = 1000000;
            if ((up_left <= down_left) and (up_left <= up_right) and (up_left <= down_right)) {
                dist.x = dist.x - 1;
                dist.y = dist.y - 1;
            }
            else if ((down_left <= up_left) and (down_left <= up_right) and (down_left <= down_right)) {
                dist.x = dist.x + 1;
                dist.y = dist.y - 1;
            }
            else if ((up_right <= up_left) and (up_right <= down_left) and (up_right <= down_right)) {
                dist.x = dist.x - 1;
                dist.y = dist.y + 1;
            }
            else if ((down_right <= up_left) and (down_right <= down_left) and (down_right <= up_right)) {
                dist.x = dist.x + 1;
                dist.y = dist.y + 1;
            }
        }
        return dist;
    }
};

#endif //HUMAN
#pragma once
