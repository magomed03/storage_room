﻿#include <iostream>
#include <random>
#include <ctime>
#include "unit.h"
#include "field.h"
#include <consoleapi2.h>
#include <WinNls.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);
    srand(time(0));
    int x1 = 0;
    int y1 = 0;
    int x2 = 4;
    int y2 = 6;
    Field field(8, 8);
    field.fill(x1, y1, x2, y2);
    field.output();
    cout << endl;
    Unit* walk = new Simple(&field, x2, y2);
    Unit* bish = new Bishop(&field, x1, y1);
    while (bish->alive() and walk->alive()) {
        walk->move(bish->get_x(), bish->get_y(), bish);
        bish->move(walk->get_x(), walk->get_y(), walk);
        field.output();
        cout << "HP Simple: " << walk->get_hp() << endl;
        cout << "coin Simple: " << walk->get_coin() << endl;
        cout << "HP Bishop: " << bish->get_hp() << endl;
        cout << "coin Bishop: " << bish->get_coin() << endl;
    }
    cout << "Бой окончен!";
    return 0;
}
