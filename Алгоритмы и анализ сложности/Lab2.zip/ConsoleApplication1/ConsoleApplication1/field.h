#ifndef FIELD
#define FIELD
using namespace std;

class Field {
public:
    int w, h;
    char** matrix;
    Field(int w, int h) {
        this->w = w;
        this->h = h;
        matrix = new char* [w];
        for (int i = 0; i < h; i++) {
            matrix[i] = new char[h];
        }
    }

    void fill(int x1, int y1, int x2, int y2) {
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                if (i == x1 and j == y1)
                    matrix[i][j] = '&';
                else if (i == x2 and j == y2)
                    matrix[i][j] = '@';
                else {
                    int rng = rand() % 100;
                    if (rng < 50)
                        matrix[i][j] = '_';
                    else if (rng < 70)
                        matrix[i][j] = '0';
                    else if (rng < 85)
                        matrix[i][j] = '$';
                    else
                        matrix[i][j] = '*';
                }
            }
        }
    }

    void output() {
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++)
                cout << matrix[i][j] << ' ';
            cout << endl;
        }
    }

    bool can_coin(int x, int y) {
        bool flag = matrix[x][y] == '$';
        if (flag)
            matrix[x][y] = '_';
        return flag;
    }

    bool damage(int x, int y) {
        bool flag = matrix[x][y] == '*';
        if (flag)
            matrix[x][y] = '_';
        return flag;
    }

    bool check(int x, int y) {
        if (x < 0 or x >= w or y < 0 or y >= h or matrix[x][y] == '0') {
            return false;
        }
        return true;
    }

    int matrix_weigt(int x, int y) {
        if (matrix[x][y] == '_')
            return 3;
        else if (matrix[x][y] == '0')
            return -1;
        else if (matrix[x][y] == '*')
            return 15;
        else if (matrix[x][y] == '$')
            return 1;
        if (matrix[x][y] == '&' or matrix[x][y] == '@')
            return 400000;
    }

    void output_m_w(int x, int y) {
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++)
                cout << matrix_weigt(i, j) << ' ';
            cout << endl;
        }
    }

};

#endif //FIELD
