#include <iostream>
using namespace std;

class StudBilet
{
    public:
    int min = 9, max = 0, x, a[10];
    
    // Студ билет
    void N()
    {
        cout << "студ билет: ";
        cin >> x;
    }
    
    // Обратный номер студ билета
    void R()
    {
        for(int i = 0; i < 10; i ++)
        {
            a[i] = x % 10;
            x = x / 10;
            cout << a[i];
        }
    }
    
    // Минимальное значение
    void minn()
    {
        for(int i = 0; i < 10; i ++)
        {
            if(a[i] < min)
            {
                min = a[i];
            }
        }
    cout << "\n min = " << min;
    }
    // Максимальное значение
    void maxx()
    {
        for(int i = 0; i< 10; i ++)
        {
            if(a[i] > max)
            {
                max = a[i];
            }
        }
        cout << "\n max = " << max;
    }
};
    
int main()
{
    StudBilet funkt;
    funkt.N();
    funkt.R();
    funkt.minn();
    funkt.maxx();
    return 0;
}