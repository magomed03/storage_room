#include <iostream>
#include <cstdlib>
using namespace std;

class Lab3
{
	private:
	bool **matrix;
	int n;
	char k;
	
	public:
	
	Lab3() // Конструктор
	{
		n = 0;
		k = 'p';
	}
	
	Lab3(int n) // Функция для получения матрицы(рандомно)
	{
		k = 'p';
		this->n = n;
		matrix = new bool*[n];
		for(int i = 0; i < n; i ++)
		{
			matrix[i] = new bool[n];
			for(int j = 0; j < n; j ++)
			{
				matrix[i][j] = rand() % 2;
				cout << matrix[i][j];
			}
			cout << endl;
		}
	}

	bool command(int x, int y) // Функция для команд
	{
		if(matrix[x][y] == 1 || y > n-1 || x > n-1 || y < 0 || x < 0)
		{
				return(1);
		}
		cout << "Select one of the following commands: up-'w', down-'s', right-'d', left-'a', exit-'e'or'q' " << endl;
		while(k)
		{
			cout << "We are here: (" << x << "," << y << ")" << endl << "Write command: ";
			cin >> k;
			switch(k)
			{
				case 'w':
					if(x == 0 || matrix[x-1][y] == 1)
					{
						cout << "Error, no passage!";
					}
					else
					{
					    x = x - 1;
					}
					break;
				case 's':
					if(x == n-1 || matrix[x+1][y] == 1)
					{
						cout << "Error, no passage!";
					}
					else
					{
					    x = x + 1;
					}
					break;
				case 'a':
					if(y == 0 || matrix[x][y-1] == 1)
					{
						cout << "Error, no passage!";
					}
					else
					{
					    y = y - 1;
					}
					break;
				case 'd':
					if(y == n-1 || matrix[x][y+1] == 1)
					{
						cout << "Error, no passage!";
					}
					else
					{
					    y = y + 1;
					}
					break;
				case 'e':
				case 'q':
					return(0);
			}
		    cout << endl;
		}
	    return(0);
	}
	
	~Lab3() // Деструктор
	{
		cout << "Destructor";
		for (int i = 0; i < n; i ++)
		{
			delete[] matrix[i];
		}
		delete[] matrix;
	}
};

int main()
{
    bool p;
	int x, y, n;
	cout << "Enter the size of the matrix: n = ";
	cin >> n;
	Lab3 A(n);
	p = 1;
	cout << "Enter x,y: ";
	while(p)
	{
		cin >> x >> y;
		p = A.command(x, y);
		if(p)
		{
			cout << "Wrong coordinates, enter again" << endl;
		}
	}
	return(0);
}