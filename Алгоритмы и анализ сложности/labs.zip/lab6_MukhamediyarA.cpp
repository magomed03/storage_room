#include <iostream>
#include <string>
using namespace std;

struct Elem
{
	string par;
	Elem *next;
};

class Text
{
	Elem *first;

  public:
	void addpar(int s)
	{
		Elem *noviy = new Elem;
		string k;
		getline(cin, k);
		if (s == 0)
		{
			noviy->par = k;
			first = noviy;
			first->next = NULL;
		}
		else
		{
			Elem *temp = new Elem;
			temp = first;
			for (int i = 1; i < s; i++)
				temp = temp->next;
			noviy->next = first;
			noviy->par = k;
			temp->next = noviy;
		}
	}
	void deletepar(int a, int s)
	{
		Elem *node = new Elem;
		Elem *rep = new Elem;
		node = first;
		rep = first;
		for (int i = 1; i < a; i++)
			node = node->next;
		for (int i = 1; i < a - 1; i++)
			rep = rep->next;
		if (s == 1)
		{
			delete node;
			return;
		}
		if (node == rep)
		{
			first = first->next;
			delete (node);
			rep = first;
			for (int i = 1; i < s - 1; i++)
				rep = rep->next;
			rep->next = first;
		}
		else
		{
			rep->next = node->next;
			delete (node);
		}
	}
	void swappar(int a, int b, int s)
	{
		int i;
		Elem *node = new Elem;
		Elem *sec = new Elem;
		string temp;
		if (a > b)
		{
			i = a;
			a = b;
			b = i;
		}
		sec = first;
		for (i = 1; i < b; i++)
		{
			if (i == a)
				node = sec;
			sec = sec->next;
		}
		temp = node->par;
		node->par = sec->par;
		sec->par = temp;
	}
	void display(int s)
	{
		Elem *node = new Elem;
		node = first;
		for (int i = 0; i < s; i++)
		{
			cout << node->par << endl;
			node = node->next;
		}
	}
	int findelem(string k, int s)
	{
		Elem *node = new Elem;
		node = first;
		int a = first->par.length(), j = k.length(), count = 0, o = 0, e, i;
		for (i = 0; i < a + 1; i++)
		{
			if (k[0] == first->par[i])
				while (k[o] == first->par[i])
				{
					count++;
					o++;
					i++;
					if (count == j)
						return (1);
				}
			count = 0;
			o = 0;
		}
		for (e = 1; e < s; e++)
		{
			o = 0;
			count = 1;
			node = node->next;
			a = node->par.length();
			for (i = 0; i < a + 1; i++)
				if (k[o] == node->par[i])
					while (k[o + 1] == node->par[i + 1])
					{
						count++;
						o++;
						i++;
						if (count == j)
							return (e + 1);
					}
			count = 0;
			o = 0;
		}
		return (0);
	}
	~Text()
	{
		Elem *temp = new Elem;
		temp = first;
		while (temp)
		{
			temp = temp->next;
			delete first;
			first = temp;
		}
	}
};

int main()
{
    setlocale(0, "");
	int a, b, s, c;
	string k;
	Text say;
	s = 0;
	do
	{
    		cout << "Выберите команду:\n 0 - Выход \n 1 - Ввести новый абзац \n 2 - Удалить абзац \n 3 - Поменять местами два абзаца \n 4 - Найти слово \n 5 - Найти и заменить слово \n 6 - Показать все абзацы \n Введите команду: ";
		cin >> c;
		cin.ignore();
		switch (c)
		{
		case 0:
			cout << "Завершение работы программы" << endl;
			return (0);
			break;
		case 1:
			cout << "Введите ваш текст" << endl;
			say.addpar(s);
			s = s + 1;
			cout << "Элемент успешно добавлен" << endl;
			break;
		case 2:
			if (s != 0)
			{
				cout << "Выберите абзац, для его удаления" << endl;
				cin >> a;
				cin.ignore();
				if (a > s || s == 0 || a <= 0)
				{
					cout << "Ошибка, вы не можете удалить пустую строку" << endl;
					break;
				}
				say.deletepar(a, s);
				s = s - 1;
				cout << "Элемент успешно удален" << endl;
			}
			else
				cout << "Ошибка, вы не можете удалить пустую строку" << endl;
			break;
		case 3:
			if (s >= 2)
			{
				cout << "Введите, какие абзацы вы хотите поменять местами" << endl;
				cin >> a >> b;
				cin.ignore();
				if (a > s || b > s || s == 0)
				{
					cout << "Вы не можете поменять местами пустую строку" << endl;
					break;
				}
				if (a == b)
					break;
				say.swappar(a, b, s);
				cout << "Элемент успешно заменен" << endl;
			}
			else
				cout << "Не хватает абзацев для обмена" << endl;
			break;
		case 4:
			cout << "Введите слово, которое вы хотите найти" << endl;
			cin >> k;
			if (s == 0)
			{
				cout << "Текст пуст" << endl;
				break;
			}
			cin.ignore();
			a = say.findelem(k, s);
			if (a == 0)
				cout << "В этом тексте такого слова нет" << endl;
			else
				cout << "Это слово впервые было найдено в " << a << " абзаце" << endl;
			break;
		case 6:
			say.display(s);
			break;
		default:
			cout << "Неправильная команда. Пробовать снова" << endl;
			break;
		}
	} while (c);
	return 0;
}
