#include <iostream>
using namespace std;

class Num {
    private:
    int **a;
    int number;
    
    public:
    Num(int x)
    { // Определим сколькизначное наше число
        int y = x;
        number = 0;
        while(y != 0){
            y /= 10;
            number ++;
        }
        a = new int *[number];
        for(int i = number - 1; i >= 0; i --)
        {
            a[number - i - 1] = new int [number];
            a[0][i] = x % 10;
            x /= 10;
        }
        for(int i = 0; i < number; i ++)
        {
            cout << a[0][i] << " ";
        }
        cout <<endl;
    }
    // Сдвиг
    int *Shift(int *b)
    {
        int t = b[0];
        for(int i = 0; i < number - 1; i ++)
        {
            b[i] = b[i + 1];
        }
        b[number - 1] = t;
        for(int i = 0; i < number; i ++)
        {
            cout << b[i] << " ";
        }
        cout << endl;
        return b;
    }
    // Теперь используя 1 матрицу, допишем остальные
    void made()
    {
        for(int i = 1; i < number; i ++)
        {
            a[i] = Shift(a[i-1]);
        }
    }
    // Удаляем матрицу
    ~Num()
    {
        delete a;
    }
};
int main()
{
    int k;
    cin >> k;
    Num Adil(k);
    Adil.made();
    return 0;
}
