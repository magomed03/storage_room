#include <iostream>
#include <fstream>
using namespace std;

void d(double **m, int ln)
{
	double **p;
	p = new double *[ln];
	for (int i = 0; i < ln; i++)
	{
		p[i] = new double[ln];
		for (int j = 0; j < ln; j++)
			p[i][j] = m[i][j];
	}
	for (int k = 0; k < ln - 1; k++)
	{
		for (int i = k + 1; i < ln; i++)
		{
			double tm = -p[i][k] / p[k][k];
			for (int j = 0; j < ln; j++)
			{
				p[i][j] += p[k][j] * tm;
			}
		}
	}
	double pd = 1;
	for (int i = 0; i < ln; i++)
		pd *= p[i][i];
	cout << "Определитель матрицы равен " << pd << endl;
	for (int i = 0; i < ln; i++)
		delete p[i];
	delete p;
}

void display(double **m1, double **m2, int ln)
{
	for (int i = 0; i < ln; i++)
	{
		for (int j = 0; j < ln; j++)
			cout << m1[i][j] << " ";
		cout << endl;
	}
	cout << endl;
	for (int i = 0; i < ln; i++)
	{
		for (int j = 0; j < ln; j++)
			cout << m2[i][j] << " ";
		cout << endl;
	}
}
int main(int argc, char *argv[])
{
    setlocale(LC_CTYPE, "rus");
	int ln, xp, i, j, at;
	double **m1, **m2;
	do
	{
		cout << "Как прочитать матрицу: " << endl <<  "1 - Взять из файла" << endl << "2 - Взять из командной строки" << endl;
		cout << "Ваш выбор: ";
		cin >> xp;
		switch (xp)
		{
		case 1:
		{
			ifstream input("f.txt");
			float chr;
			int count = 0;
			while (input >> chr)
				count++;
			input.close();
			i = count / 2;
			ln = 0;
			while (ln * ln < i)
				ln++;
			cout << "Размерность матриц равна: " << ln << endl;
			ifstream file("f.txt");
			m1 = new double *[ln];
			m2 = new double *[ln];
			for (i = 0; i < ln; i++)
			{
				m1[i] = new double[ln];
				for (j = 0; j < ln; j++)
					file >> m1[i][j];
			}
			for (i = 0; i < ln; i++)
			{
				m2[i] = new double[ln];
				for (j = 0; j < ln; j++)
					file >> m2[i][j];
			}
			file.close();
			break;
		}
		case 2:
		{
			cout << "Введите размерность матриц: ";
			cin >> ln;
			m1 = new double *[ln];
			m2 = new double *[ln];
			for (i = 0; i < ln; i++)
			{
				m1[i] = new double[ln];
				for (j = 0; j < ln; j++)
				{
				    cout << "Введите " << j + 1 << " элемент " << i + 1 << " строки первой матрицы: " << endl;
					cin >> m1[i][j];
				}
			}
			for (i = 0; i < ln; i++)
			{
				m2[i] = new double[ln];
				for (j = 0; j < ln; j++)
				{
				    cout << "Введите " << j + 1 << " элемент " << i + 1 << " строки второй матрицы: " << endl;
					cin >> m2[i][j];
				}
			}
			break;
		}
		}
		do
		{
			cout << "Выберите одну из следующих команд" << endl;
			cout << "0 - Завершение программы \n 1 - Сумма матриц \n 2 - Вычтите одну матрицу из другой \n 3 - Умножение двух матриц" << endl;
			cout << "4 - Найти определитель \n 5 - Показать матрицы \n 6- Работа с другими матрицами" << endl << endl;
			cout << "Введите команду: ";
			cin >> at;
			switch (at)
			{
			case 0:
				cout << "Завершение программы";
				return (0);
			case 1:
				for (i = 0; i < ln; i++)
					for (j = 0; j < ln; j++)
						m1[i][j] = m1[i][j] + m2[i][j];
				break;
			case 2:
				for (i = 0; i < ln; i++)
					for (j = 0; j < ln; j++)
						m1[i][j] = m1[i][j] - m2[i][j];
				break;
			case 3:
			{
				double **m3 = new double *[ln];
				for (i = 0; i < ln; i++)
				{
					m3[i] = new double[ln];
					for (j = 0; j < ln; j++)
					{
						m3[i][j] = 0;
						for (int k = 0; k < ln; k++)
							m3[i][j] += m1[i][k] * m2[k][j];
					}
				}
				for (i = 0; i < ln; i++)
				{
					for (j = 0; j < ln; j++)
						m1[i][j] = m3[i][j];
					delete m3[i];
				}
				delete[] m3;
				break;
			}
			case 4:
				cout << "Выберите определитель какой матрицы хотите найти: ";
				cin >> i;
				if (i == 1)
					d(m1, ln);
				else
					d(m2, ln);
				break;
			case 5:
				display(m1, m2, ln);
				break;
			case 6:
				break;
			}
		} while (at != 6);
	} while (xp);
	return 0;
}