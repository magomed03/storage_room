#!/usr/bin/env python
# coding: utf-8

# # AI 1

# ### 1 Написать программу, которая итерируется по тексту и выбирает все триплеты (множества из подряд идущих букв). В триплетах не может быть пробелов, знаков пунктуации. Пример триплетов из фразы "Мама, мыла раму?": мам, ама, мыл, ыла, рам, аму

# #### результат 3/3

# In[ ]:


import re
from datetime import datetime
data = input()
data_clean = [i for i in re.split(r'\W+',data) if i]
A = []
for i in range(len(data_clean)):
    strng = data_clean[i]
    A.append([strng[i:i+3] for i in range(len(strng)-2)])

for row in A: 
    for x in row: 
        print(x)


# #### результат 3/3

# In[10]:


s = input()
for i in range(len(s)-2):
    if s[i:i+3].isalpha() :
        print(s[i]+s[i+1]+s[i+2]) 


# #### ВАНЕ

# In[1]:


vvod = input()
for i in range(len(vvod)-2):
    if vvod[i:i+3].isalpha() :
        print(vvod[i]+vvod[i+1]+vvod[i+2]) 


# ### 2 Создать программу, которая выбирает из текста все даты, которые записаны в формате: dd.mm.yyyy и сохранить их в формате datetime

# #### результат 3/3

# In[ ]:


import re
from datetime import datetime
data2 = input()
date_string  = re.findall(r'\d{2}\.\d{2}\.\d{4}', data2)
date_list = []
for i in range(len(date_string)):
    date_list.append(datetime.strptime(date_string[i], "%d.%m.%Y"))
    
for row in date_list:
    print(row.strftime("%Y-%m-%d"))


# #### результат 3/3

# In[6]:


import datetime
t = input()
for i in range(len(t)-9):
    if(t[i].isdigit()) and (t[i+1].isdigit()) and (t[i+2] == ".") and (t[i+3].isdigit()) and (t[i+4].isdigit()) and ( t[i+5] == "." ) and ( t[i+6].isdigit()) and ( t[i+7].isdigit()) and ( t[i+8].isdigit()) and ( t[i+9].isdigit()):
        print(t[i+6]+t[i+7]+t[i+8]+t[i+9]+"-"+t[i+3]+t[i+4]+"-"+t[i]+t[i+1])


# #### ВАНЕ

# In[7]:


import datetime
vvod = input()
for i in range(len(vvod)-9):
    if(vvod[i].isdigit()) and (vvod[i+1].isdigit()) and (vvod[i+2] == ".") and (vvod[i+3].isdigit()) and (vvod[i+4].isdigit()) and ( vvod[i+5] == "." ) and ( vvod[i+6].isdigit()) and ( vvod[i+7].isdigit()) and ( vvod[i+8].isdigit()) and ( vvod[i+9].isdigit()):
        print(vvod[i+6]+vvod[i+7]+vvod[i+8]+vvod[i+9]+"-"+vvod[i+3]+vvod[i+4]+"-"+vvod[i]+vvod[i+1])


# ### 3 N учеников поровну делят K яблок, оставив оставшиеся яблоки в корзине. Сколько яблок получит каждый ученик?

# #### результат 4/4

# In[9]:


a = int(input())
b = int(input())
if a*b==0:
    print("0")
else:
    print(int(b)//int(a))


# #### результат 4/4

# In[7]:


stud = int(input())
apple = int(input())
if stud ==0:
    print (0)
else:
    ans = apple // stud
    print (ans)


# #### ВАНЕ

# In[9]:


num = int(input())
kol = int(input())
if num*kol==0:
    print("0")
else:
    print(int(kol)//int(num))


# ### 4 Вывести последнюю цифру целого числа N.

# #### результат 3/3

# In[11]:


a = int(input())
print(a%10)


# #### результат 3/3

# In[6]:


n = int(input())
while n>10:
    n = n % 10
print (n)


# #### ВАНЕ

# In[10]:


vvod = int(input())
print(vvod%10)


# ### 5 Задано число N. С начала дня (00:00) прошло N минут. Преобразуйте время в этот момент в часы и минуты, которые покажут цифровые часы.

# #### результат 4/4

# In[ ]:


a = int(input())
hh = a % (60*24) // 60
mm = a%60
if(mm<10):
    print(hh,":0", mm, sep="")
else:
    print(hh,":", mm, sep="")


# #### результат 4/4

# In[5]:


n = int(input())
while n>1440:
    n=n-1440
hour = n // 60
ans = str(hour)+":"
minu = n - hour*60

if minu < 10:
    print (ans+"0"+str(minu))
else:
    print (ans+str(minu))


# #### ВАНЕ

# In[11]:


vvod = int(input())
while vvod>1440:
    vvod=vvod-1440
h = vvod // 60
viv = str(h)+":"
m = vvod - h*60

if m < 10:
    print (viv+"0"+str(m))
else:
    print (viv+str(m))


# ### 6 Даны три целых числа. Определите, сколько из них совпадают.

# #### результат 3/3

# In[14]:


a = int(input())
b = int(input())
c = int(input())
if a == b == c:
    print(3)
elif a==b or b==c or a==c:
    print(2)
else:
    print(0)


# #### ВАНЕ

# In[11]:


a1 = int(input())
a2 = int(input())
a3 = int(input())

if a1 == a2 == a3:
    print(3)
elif a1 != a2 and a3 != a1 and a2 != a3:
    print(0)
else:
    print(2)


# ### 7 Даны два ящика размерами A1 × B1 × C1 и A2 × B2 × C2. Можно ли разместить одну коробку внутри другой, имея параллельные стороны коробок?

# #### результат 5/5

# In[12]:


A = [0,0,0]
B =[0,0,0]
for i in range(3):
    A[i] = input()
for i in range(3):
    B[i] = input()

A.sort()
B.sort()
if (A[0] == B[0] and A[1] == B[1] and A[2] == B[2]):
    print("Ящики равны")
elif (A[0] <= B[0] and A[1] <= B[1] and A[2] <= B[2]):
    print("Первое поле меньше второго")
elif (A[0] >= B[0] and A[1] >= B[1] and A[2] >= B[2]):
    print("Первое поле больше второго")
else:
    print("Ящики несопоставимы")


# #### ВАНЕ

# In[12]:


b1 = [0,0,0]
b2 =[0,0,0]
for i in range(3):
    b1[i] = input()
for i in range(3):
    b2[i] = input()

b1.sort()
b2.sort()
if (b1[0] == b2[0] and b1[1] == b2[1] and b1[2] == b2[2]):
    print("Ящики равны")
elif (b1[0] <= b2[0] and b1[1] <= b2[1] and b1[2] <= b2[2]):
    print("Первое поле меньше второго")
elif (b1[0] >= b2[0] and b1[1] >= b2[1] and b1[2] >= b2[2]):
    print("Первое поле больше второго")
else:
    print("Ящики несопоставимы")


# ### 8 Для заданных n <100 завершают русскую фразу «На лугу пасется ...» одним из следующих окончаний: «n коров» «n корова» «n коровы».

# #### результат 4/4

# In[ ]:


n = int(input())

if n >= 11 and n <= 14:
        print(n, 'коров')
else:
        temp = n % 10
        if temp == 0 or (temp >= 5 and temp <= 9):
                print(n, 'коров')
        if temp == 1:
                print(n, 'корова')
        if temp >=2 and temp <=4:
                print(n, 'коровы')


# #### результат 4/4

# In[ ]:


n = int(input())
if (n !=11 and n%10 == 1):
    print( n, 'корова')
elif (2 <= n % 10 <= 4 and n!=12 and n!=13 and n!=14):
    print ( n, 'коровы')
elif (5 <= n % 10 <= 9 or n % 10 == 0 or n==11 or n==12 or n==13  or n==14):
    print( n, 'коров')


# #### ВАНЕ

# In[ ]:


kolvo = int(input())
if (kolvo !=11 and kolvo%10 == 1):
    print( kolvo, 'корова')
elif (2 <= kolvo % 10 <= 4 and kolvo!=12 and kolvo!=13 and kolvo!=14):
    print ( kolvo, 'коровы')
elif (5 <= kolvo % 10 <= 9 or kolvo % 10 == 0 or kolvo==11 or kolvo==12 or kolvo==13  or kolvo==14):
    print( kolvo, 'коров')


# # AI 2

# ### 1 Реализуйте функцию со следующим функционалом. Найти наименьшее общее кратное (НОК) пар чисел по формуле НОК = ab / НОД(a,b), где a и b - это натуральные числа, НОД - наибольший общий делитель.

# #### результат 5/5

# In[ ]:


def gcd(a, b):

    while b:
        a, b = b, a%b
    return a
def lcm(a, b):
    return a * b / gcd(a, b)

a = int(input())
b = int(input())

r = lcm(a, b)
print(int(r))


# #### результат 5/5

# In[ ]:


a = int(input())
b = int(input())
if a != 0 and b != 0:
    for i in range (1, a*b+1):
        if i%b == 0 and i%a == 0:
            print(i)
            break
else:
    print(0)


# #### ВАНЕ

# In[ ]:


f = int(input())
s = int(input())
if f != 0 and s != 0:
    for i in range (1, f*s+1):
        if i%s == 0 and i%f == 0:
            print(i)
            break
else:
    print(0)


# ### 2 Реализовать функцию со следующим функционалом: найти сумму цифр произвольного положительного числа.

# #### результат 4/4

# In[ ]:


def sum_of_digits(val):
    val = str(val)
    return sum(map(int, val))

a = int(input())
print(int(sum_of_digits(a)))


# #### результат 4/4

# In[ ]:


a=int(input())
s=0
while a >0:
    s+=a%10
    a = a//10
print(s+a)


# #### ВАНЕ

# In[ ]:


vvod=int(input())
suma=0
while vvod >0:
    suma+=vvod%10
    vvod = vvod//10
print(suma+vvod)


# ### 3 Проверить является ли число простым. Реализовать в виде функции, принимающей один аргумент и возвращающей True или False.

# #### результат 6/6

# In[ ]:


def eratosthenes(n):
    sieve = list(range(n + 1))
    sieve[1] = 0
    for i in sieve:
        if i > 1:
            for j in range(i + i, len(sieve), i):
                sieve[j] = 0
    return sieve[-1] == n

a = int(input())
print(eratosthenes(a))


# #### ВАНЕ

# In[12]:


def prov(v):
    s = list(range(v + 1))
    s[1] = 0
    for i in s:
        if i > 1:
            for j in range(i + i, len(s), i):
                s[j] = 0
    return s[-1] == v

vvod = int(input())
print(prov(vvod))


# ### 4. Создайте программу с классом Algebra. Создайте два атрибута — х и у. Напишите методы add, mult, divis, subtr, sqrt, pov — основные математические операции. При передаче в методы параметров x и y с ними нужно производить соответствующие действия и печатать ответ.

# #### результат 4/4 

# #### ВАНЕ

# In[14]:


class Algebra(object): 
    
    def __init__(self, a, b):
        self.a = a
        self.b = b
        
    def add(self):
        print(a+b)
    
    def mult(self):
        print(a*b)
    
    def divis(self):
        if b == 0:
            print ("Деление невозможно")
        else: 
            print(a / b)
    
    def subrt(self):
        print(a-b)
    
    def sqrt(self):
            print(a**(1/2))
    
    def pov(self):
        print(a**b)
    
a = int(input())
b = int(input())
alg = Algebra(a,b)

Algebra.add(alg)
Algebra.mult(alg)
Algebra.divis(alg)
Algebra.subrt(alg)
Algebra.sqrt(alg)
Algebra.pov(alg)


# ### 5 Создайте программу с классом Student и Starosta. Класс Starosta должен наследоваться от класса Student. Атрибутами класса Student должны быть bilnum - номер студбилета длинною 9 цифр, FIO - ФИО студента без цифр, знаков препинания, разрешены только пробелы, rating - рейтинг успеваемости от 0 до 100. Методы класса Student - printinf - выводит всю имеющуюся информацию по студенту, change_rating - при передаче отрицательного числа понижает рейтинг, а положительного увеличивает его. Атрибут класса Starosta - journal - словарь всех студентов, в котором ФИО указывается в виде ключа, а значение - как журнал оставшихся bilnim и rating, где ключ это bilnum, а rating это значение. Методы класса Starosta - addstudent (пополнение словаря), removestudent (удаление данных из словаря), showclass (вывод на экран всего списка студентов в по алфавиту).

# In[ ]:


#### результат 3/3 (ОБЯЗАТЕЛЬНО СМЕНИТЬ ПЕРЕМЕННЫЕ ПОВТОРНО, А ТАКЖЕ ПОСТАРАТЬСЯ ПЕРЕДЕЛАТЬ КОД ПОД СЕБЯ)


# In[1]:


class Student(object): 
    
    def __init__(self, FIO, bilnum,  rating):
        self.FIO = FIO
        self.bilnum = bilnum
        self.rating = rating
        
    def printinf(self):
        return self.FIO, self.bilnum, self.rating
    
    def change_rating(self, izmen):
        self.rating+=izmen
        if self.rating>100 :
            self.rating = 100
        elif self.rating < 0:
            self.rating = 0
    
class Starosta(Student): 
    
    def __init__(self, FIO, bilnum, rating, journ):
        super().__init__(FIO,bilnum, rating)
        self.journ = journ
        journ[FIO]={bilnum:rating}
    
    def addstudent(self, FIO, bilnum, rating, journ):
        journ[FIO]={bilnum:rating}
    
    def removestudent(self, FIO, journ):
        del journ[FIO]
    
    def showclass(self):
        keys=list(journ.keys())
        keys.sort()
        for i in keys:
            print(i, ":", self.journ[i])
        
inform = []
for i in range(6):
    inf = input()
    inform.append(inf)
change = int(input())
journ = {}

student1 = Student(inform[0], int(inform[1]), int(inform[2]))
print(student1.printinf())

Student.change_rating(student1, change)
print(student1.printinf())

student2 = Student(inform[3], int(inform[4]), int(inform[5]))
print(student2.printinf())

st = Starosta(student1.FIO, student1.bilnum, student1.rating, journ)
st.showclass()

st.addstudent(student2.FIO, student2.bilnum, student2.rating, journ)
st.showclass()

st.removestudent(student1.FIO, journ)
st.showclass()


# #### ВАНЕ

# In[18]:


class Student(object): 
    
    def __init__(self, FIO, bilnum,  rating):
        self.FIO = FIO
        self.bilnum = bilnum
        self.rating = rating
        
    def printinf(self):
        return self.FIO, self.bilnum, self.rating
    
    def change_rating(self, izmen):
        self.rating+=izmen
        if self.rating>100 :
            self.rating = 100
        elif self.rating < 0:
            self.rating = 0
    
class Starosta(Student): 
    
    def __init__(self, FIO, bilnum, rating, jrn):
        super().__init__(FIO,bilnum, rating)
        self.jrn = jrn
        jrn[FIO]={bilnum:rating}
    
    def addstudent(self, FIO, bilnum, rating, jrn):
        jrn[FIO]={bilnum:rating}
    
    def removestudent(self, FIO, jrn):
        del jrn[FIO]
    
    def showclass(self):
        keys=list(jrn.keys())
        keys.sort()
        for i in keys:
            print(i, ":", self.jrn[i])
        
tabl_inf = []
for i in range(6):
    inf = input()
    tabl_inf.append(inf)
rate_ch = int(input())
jrn = {}

Student1 = Student(tabl_inf[0], int(tabl_inf[1]), int(tabl_inf[2]))
print(Student1.printinf())

Student.change_rating(Student1, rate_ch)
print(Student1.printinf())

Student2 = Student(tabl_inf[3], int(tabl_inf[4]), int(tabl_inf[5]))
print(Student2.printinf())

st = Starosta(Student1.FIO, Student1.bilnum, Student1.rating, jrn)
st.showclass()

st.addstudent(Student2.FIO, Student2.bilnum, Student2.rating, jrn)
st.showclass()

st.removestudent(Student1.FIO, jrn)
st.showclass()

