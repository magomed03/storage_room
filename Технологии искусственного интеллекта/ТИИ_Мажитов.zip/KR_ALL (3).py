#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#### №1


# In[8]:


array = [36,55,36,40,35,35,93,78,22,47]
for i2 in range(0,len(array)):
    array[i2] = int(input())
x = 0
while (1 == 1):
    y = 0
    for i in range(0,len(array)-1):
        if (array[i] > array[i+1]):
            ost = array[i]
            array[i] = array[i+1]
            array[i+1] = ost
            y += 1
    if (y == 0):
        break
    else:
        print(array)
        x += 1
for i in range (x,len(array)):
    print(array)


# In[6]:


a = [0,0,0,0,0,0,0,0,0,0]
for i2 in range(0,len(arr)):
    a[i2] = int(input())
x = 0
while (1 == 1):
    c = 0
    for i in range(0,len(arr)-1):
        if (a[i] > a[i+1]):
            b = a[i]
            a[i] = a[i+1]
            a[i+1] = b
            c += 1
    if (c == 0):
        break
    else:
        print(a)
        x += 1
for i in range (x,len(a)):
    print(a)


# In[2]:


data = [int(input()) for _ in range(10)]

def buble_sort(data):
    n = len(data)
    
    for i in range(n-1):
        for j in range(n-i-1):
            if data[j] > data[j+1]:
                data[j], data[j+1] = data[j+1], data[j]
        print(data)
        
d = data.copy()
buble_sort(d)
print(d)


# In[ ]:


##### №2


# In[14]:


d_first = {'один' : 1,'два' : 2,'три' : 3,'четыре' : 4,'пять' : 5,'шесть' : 6,'семь' : 7,'восемь' : 8,'девять' : 9,'десять' : 10,'двадцать' : 20,'тридцать' : 30,'сорок' : 40,'пятьдесят' : 50,'шестьдесят' : 60,'семьдесят' : 70,'восемьдесят' : 80,'девяносто' : 90}
d_second = {'одиннадцать' : 11,'двенадцать' : 12,'тринадцать' : 13,'четырнадцать' : 14,'пятьнадцать' : 15,'шестнадцать' : 16,'семнадцать' : 17,'восемнадцать' : 18,'девятнадцать' : 19,'сто' : 100}
text = input().lower().split()
if (len(text) == 1):
    if (text[0] in d_first):
        print(d_first[text[0]])
    if (text[0] in d_second):
        print(d_second[text[0]])
if (len(text) == 2):
    if (text[0] in d_first and text[1] in d_first):
        print(d_first[text[0]]+d_first[text[1]])


# In[ ]:


##### №3


# In[15]:


arr= { 'Лопахин': {'Должность': 'купец', 'Возраст': 35, 'Пол': 'Мужской'},
       'Фирс': {'Должность': 'лакей', 'Возраст': None, 'Пол': 'Мужской'},
       'Трофимов': {'Должность': 'Дворянин', 'Возраст': 47, 'Пол': 'Мужской'},
       'Яша' : {'Должность': 'лакей', 'Возраст': 28, 'Пол': 'Мужской'},
       'Варя': {'Должность': 'воспитанница', 'Возраст': 24, 'Пол': 'Женский'},
       'Аня': {'Должность': 'дочь', 'Возраст': 17, 'Пол': 'Женский'},
       'Дуняшка': {'Должность': 'горничная', 'Возраст': None, 'Пол': 'Женский'},
       'Шарлотта' : {'Должность': 'гувернантка', 'Возраст': 40, 'Пол': 'Женский'},
       'Раневская' : {'Должность': 'Дворянка', 'Возраст': 32, 'Пол': 'Женский'} }

avg_m = 0
avg_f = 0
amt_m = 0
amt_f = 0

for i in arr:

    if (arr[i]['Пол'] == 'Мужской' and arr[i]['Возраст'] != None):
        avg_m += arr[i]['Возраст']
        amt_m += 1
    if (arr[i]['Пол'] == 'Женский' and arr[i]['Возраст'] != None):
        avg_f += arr[i]['Возраст']
        amt_f += 1
if (amt_f != 0):        
    avg_f = int(avg_f/amt_f)
if (amt_m != 0): 
    avg_m = int(avg_m/amt_m)

for i in arr:
    if (arr[i]['Возраст'] == None):
        if (arr[i]['Пол'] == 'Мужской' and avg_m != 0):
            arr[i]['Возраст'] = avg_m
        if (arr[i]['Пол'] == 'Женский' and avg_m != 0):
            arr[i]['Возраст'] = avg_f


for i in arr:
    if (arr[i]['Пол'] == 'Мужской' and arr[i]['Возраст'] != None and arr[i]['Возраст'] > 30):
        print (i + " " + str(arr[i]['Возраст']) + " " + str(arr[i]['Должность']))

for i in arr:
    if (arr[i]['Пол'] == 'Женский' and arr[i]['Возраст'] != None and arr[i]['Возраст'] < 24):
        print (i + " " + str(arr[i]['Возраст']) + " " + str(arr[i]['Должность']))


# In[22]:


## решено на 1 из 1
import statistics

a = []
b = []
c = 0
d = 0
array= { 'Лопахин': {'Должность': 'купец', 'Возраст': 35, 'Пол': 'Мужской'},
       'Фирс': {'Должность': 'лакей', 'Возраст': None, 'Пол': 'Мужской'},
       'Трофимов': {'Должность': 'дворянин', 'Возраст': 47, 'Пол': 'Мужской'},
       'Яша' : {'Должность': 'лакей', 'Возраст': 28, 'Пол': 'Мужской'},
       'Варя': {'Должность': 'воспитанница', 'Возраст': 24, 'Пол': 'Женский'},
       'Аня': {'Должность': 'дочь', 'Возраст': 17, 'Пол': 'Женский'},
       'Дуняшка': {'Должность': 'горничная', 'Возраст': None, 'Пол': 'Женский'},
       'Шарлотта' : {'Должность': 'гувернантка', 'Возраст': 40, 'Пол': 'Женский'},
       'Раневская' : {'Должность': 'дворянка', 'Возраст': 32, 'Пол': 'Женский'} }
for i in array:
    if (array[i]['Пол'] == 'Мужской' and array[i]['Возраст'] != None):
        a.append(array[i]['Возраст'])
    if (array[i]['Пол'] == 'Женский' and array[i]['Возраст'] != None):
        b.append(array[i]['Возраст'])

c = statistics.median(a)
d = statistics.median(b)
    
for i in array:
    if (array[i]['Возраст'] == None):
        if (array[i]['Пол'] == 'Мужской' and a != 0):
            array[i]['Возраст'] = c
        if (array[i]['Пол'] == 'Женский' and a != 0):
            array[i]['Возраст'] = d

for i in array:
    if (array[i]['Пол'] == 'Мужской' and array[i]['Возраст'] != None and array[i]['Возраст'] > 30):
        print (i + " " + str(array[i]['Возраст']) + " " + str(array[i]['Должность']))
for i in array:
    if (array[i]['Пол'] == 'Женский' and array[i]['Возраст'] != None and array[i]['Возраст'] < 24):
        print (i + " " + str(array[i]['Возраст']) + " " + str(array[i]['Должность']))


# In[ ]:


##### №4


# In[17]:


n = 4
st = 1
fin = 4
matr= [
    [0,-5,16,9],
    [5,0,4,2],
    [-16,-4,0,-3],
    [-9,-2,3,0]
    ]
paths = [0]*n
visit = [0]*n

enter = 1

if (enter == 1):
    i1 = input().split()
    if (len(i1) == 3):
        n = int(i1[0])
        st = int(i1[1])
        fin = int(i1[2])
        matr = [[0 for col in range(n)] for row in range(n)]
    else:
        exit()
    for i in range(n):
        im = input().split()
        if (len(im) == n):
            for i2 in range(n):
                matr[i][i2] = int(im[i2])
        else:
            exit()

def calc_paths(mat, vis, v):
    if (vis[v] == 0):
        vis[v] = 1
        for i in range(n):
            #print(i)
            if (i != v and mat[v][i] > 0):
                if (paths[i] == 0 ):
                    paths[i] = mat[v][i]
                    calc_paths(mat,vis,i)
                if (paths[i] > paths[v]+mat[v][i]):
                    paths[v]+mat[v][i]
                    calc_paths(mat,vis,i)
    
        
            

arr = ("0 -5 16 9".split())
arr = list(map(int,arr))
calc_paths(matr,visit,st-1)
if (paths[fin-1] == 0):
    print (None)
else:
    print(paths[fin-1])


# In[24]:


n = 4
st = 1
fin = 4
matr= [[0,-5,16,9],
    [5,0,4,2],
    [-16,-4,0,-3],
    [-9,-2,3,0]]
a = [0]*n
b = [0]*n

enter = 1
if (enter == 1):
    i1 = input().split()
    if (len(i1) == 3):
        n = int(i1[0])
        st = int(i1[1])
        fin = int(i1[2])
        matr = [[0 for col in range(n)] for row in range(n)]
    else:
        exit()
    for i in range(n):
        im = input().split()
        if (len(im) == n):
            for i2 in range(n):
                matr[i][i2] = int(im[i2])
        else:
            exit()
def algor(mat, vis, v):
    if (vis[v] == 0):
        vis[v] = 1
        for i in range(n):
            #print(i)
            if (i != v and mat[v][i] > 0):
                if (a[i] == 0 ):
                    a[i] = mat[v][i]
                    algor(mat,vis,i)
                if (a[i] > a[v]+mat[v][i]):
                    a[v]+mat[v][i]
                    algor(mat,vis,i)
    
array = ("0 -5 16 9".split())
array = list(map(int,array))
algor(matr,b,st-1)
if (a[fin-1] == 0):
    print (None)
else:
    print(a[fin-1])


# In[31]:


## решено на 6 из 6 
def algor(n, k, m, m_x, put, mrk):
    while True:
        m_d = m_x
        for i in range(n):
            if not mrk[i] and put[i] < m_d:
                m_d = put[i]
                m_v = i
        if m_d == m_x:
            break
        i = m_v
        mrk[i] = True
        for j in range(n):
            if put[i] + m[i][j] < put[j] and m[i][j] > 0:
                put[j] = put[i] + m[i][j]
    if put[k - 1] == m_x:
        print(None)
    else:
        print(put[k - 1])


num, nach, kon = map(int, input().split())
m = []
for i in range(num):
    m.append(list(map(int, input().split())))

mx = 1000
put = [mx] * num
put[nach - 1] = 0
mark = [False] * num
global m_v

algor(num, kon, m, mx, put, mark)


# In[ ]:




