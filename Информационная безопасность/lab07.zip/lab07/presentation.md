---
## Front matter
lang: ru-RU
title: Презентация по лабораторной работе №7
subtitle: Информационная безопасность
author:
  - Мухамедияр А.
institute:
  - Российский университет дружбы народов, Москва, Россия
date: 21 октября 2023

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---

# Информация

## Докладчик

:::::::::::::: {.columns align=center}
::: {.column width="70%"}

  * Мухамедияр Адиль
  * студент 4 курса группы НКНбд-01-20
  * ст. б. 1032205725
  * Российский университет дружбы народов
  * [GitHub](https://github.com/adil-cpu)

:::
::::::::::::::

# Вводная часть

## Цели и задачи

- Освоение на практике применение режима однократного гаммирования
- Написание программы для шифрования сообщений

## Материалы и методы

- Веб-сервис `GitHub` для работы с репозиториями
- Интерактивный блокнот `Jupyter` для работы на языке `Python`
- Процессор `pandoc` для входного формата Markdown
- Результирующие форматы
	- `pdf`
	- `docx`
- Автоматизация процесса создания: `Makefile`

# Ход работы

## Первая часть кода

![Код(1)](img/1.png)

## Вторая часть кода

![Код(2)](img/2.png)

# Результаты

## Результаты работы

- Рассмотрены основные элементы криптографии
- Получены базовые навыки применения однократного гаммирования