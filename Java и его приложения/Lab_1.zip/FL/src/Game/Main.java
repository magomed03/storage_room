package Game;


import java.util.Scanner;

public class Main {
    public static void main(String[] args)  {

        Map start = new Map();
        start.SetArraySize();
        if(start.GetPlayerChoice()==0)
        {

        }
        else
        {

        }



    }


}

