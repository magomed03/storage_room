package Game;

public abstract class Player extends Map
{
    double hp,dmg;

    public abstract void Initialize();

    public abstract double GetHp();

    public abstract double GetDmg();

    

    public abstract void Logic();


}
