package Game;
//Hierarchical inheritance
public class Knight extends Player {


    @Override
    public void Initialize() {

    }

    @Override
    public double GetHp() {
        return 0;
    }


    @Override
    public double GetDmg() {
        return 0;
    }



    @Override
    public void Logic() {

    }


}
