#include "graphics.h"
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <direct.h>
#include <fstream>
#include <iostream>
#include <stdio.h>

class Point {
	public:
	double x, y, z;
	Point() {
		x = 0; y = 0; z = 0;
	} 
	Point(double x1, double y1, double z1) {
	x = x1; y = y1; z = z1;
	}
};

class vertex {
	public:
	Point worldcoord;
	Point viewcoord;
	vertex () {};
	void world_coord (Point A) {
		worldcoord = A;
	}
	void set_view_coord (Point t) {
		double ro = t.x;
		double teta = t.y;
		double fi = t.z;
		viewcoord.x = -worldcoord.x * sin (teta) + worldcoord.y * cos(teta);
		viewcoord.y = -worldcoord.x * cos(fi) * cos(teta) - worldcoord.y * cos(fi) * sin(teta) + worldcoord.z * sin (fi);
		viewcoord.z = -worldcoord.x * sin(fi) * cos(teta) - worldcoord.y * sin (fi) * sin (teta) - worldcoord.z * cos(fi) + ro;
	}
};

class edge {
	private:
	vertex startvert;
	vertex finishvert;
	
	public:
	edge () {};
	void edgeends (vertex sv, vertex fv) {
		startvert = sv;
		finishvert = fv;
	}
	~edge () {};
	void drawedge(double ro) {
		double x1 = (ro / (2*startvert.viewcoord.z)) * startvert.viewcoord.x;
		double y1 = (ro / (2*startvert.viewcoord.z)) * startvert.viewcoord.y;
		double x2 = (ro / (2*finishvert.viewcoord.z)) * finishvert.viewcoord.x;
		double y2 = (ro / (2*finishvert.viewcoord.z)) * finishvert.viewcoord.y;
		line (x1  + getmaxx()/2, y1 + getmaxy()/2, x2 + getmaxx()/2, y2 + getmaxy()/2);
	} 
};

struct strk {
	public: 
	int a, b;
};

class surface {
	private:
	vertex *vl;
	edge *el;
	strk *strk1;
	Point viewpoint;
	bool open = false;
	
	public:
	friend class edge;
	friend class vertex;
	int n, m;
	void setviewpoint(double ro, double tetaangle, double fiangle)	{
		viewpoint.x = ro;
		viewpoint.y = tetaangle;
		viewpoint.z = fiangle;
	}
	void draw() {
		for (int i = 0; i < m; i++) el[i].drawedge(viewpoint.x);
		}
	void drawing() {
		int a, b, c;
		if (!open) {
			FILE *k;
			k = fopen("obj2.txt","r");
			if (k != NULL) {
				fscanf (k, "%d", &n);
				vl = new vertex[n];
				for (int i = 0; i < n; i++) {
					fscanf(k, "%d", &a);
					fscanf(k, "%d", &b);
					fscanf(k, "%d", &c);
					Point p = Point (a*30, b*30, c*30);
					vl[i].world_coord(p);
					vl[i].set_view_coord(viewpoint);
				}
				fscanf(k, "%d", &m);
				el = new edge[m];
				strk1 = new strk[m];
				for (int i = 0; i < m; i++) {
					fscanf(k, "%d", &a);
					fscanf(k, "%d", &b);
					strk1[i].a = a;
					strk1[i].b = b;
					el[i].edgeends(vl[strk1[i].a - 1], vl[strk1[i].b - 1]);
				}
				open = true;
			}
		}
	}
};

int main() {
	int gddriver = DETECT, gmode, errorcode;
	initgraph(&gddriver, &gmode, "");
	setcolor(11); 
	surface obj; 
	obj.setviewpoint(100, 0*(M_PI/180), 260*(M_PI/180));
	obj.drawing();
	obj.draw();
	getch();
	closegraph();
	return 0;
}
